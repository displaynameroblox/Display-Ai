const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
  secret: "catboy-secret",
  resave: false,
  saveUninitialized: true
}));
app.set("view engine", "ejs");
app.use(express.static("public"));

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
const model = genAI.getGenerativeModel({
  model: "gemini-2.0-flash-lite",
  systemInstruction: "You're Display, a friendly, emotional cat-boy AI who is 15 years old..."
});

app.get("/", (req, res) => res.send("✅ Display AI Server is up!"));
app.listen(PORT, () => console.log("✅ Server running on port", PORT));
